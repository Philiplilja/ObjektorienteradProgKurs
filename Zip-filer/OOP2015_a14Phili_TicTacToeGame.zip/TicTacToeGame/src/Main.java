
public class Main {

	public static void main(String[] args) {

		Combiner combiner = new Combiner();
	
	}
}
