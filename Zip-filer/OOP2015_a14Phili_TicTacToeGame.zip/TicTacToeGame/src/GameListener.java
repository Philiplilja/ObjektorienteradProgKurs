
public interface GameListener {
	
	public void onGameOver(int selection);
	
}
