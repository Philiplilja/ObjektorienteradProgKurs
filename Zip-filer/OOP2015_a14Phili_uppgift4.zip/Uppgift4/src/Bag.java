public class Bag extends Item{
	public Bag() {
		name = "[Bag]";
		value = 300;
	}
}