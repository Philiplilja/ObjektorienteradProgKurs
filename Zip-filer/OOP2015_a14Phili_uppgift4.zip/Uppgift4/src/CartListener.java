
public interface CartListener {

	public void onAddItem(Item item);
	public void onClear();
}
