public class Bicycle extends Item {
	public Bicycle() {
		name = "[Bicycle]";
		value = 1995;
	}
}