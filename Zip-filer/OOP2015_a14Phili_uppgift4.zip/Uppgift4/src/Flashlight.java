public class Flashlight extends Item{
	public Flashlight() {
		name = "[Flashlight]";
		value = 99;
	}
}